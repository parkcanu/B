package main

import "fmt"

func main() {
	println("Hello Go!")
	fmt.Println("OpenSource Programming~", "Go")
}
